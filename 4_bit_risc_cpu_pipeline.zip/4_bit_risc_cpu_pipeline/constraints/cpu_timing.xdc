# Timing constraint for cpu_top (optional; only needed for synthesis/implementation).
# Without a clock constraint Vivado reports timing as "unconstrained".
# 10 ns = 100 MHz as a starting point; raise or lower the period to find the
# fastest clock that still gives positive slack (WNS >= 0).
create_clock -period 10.000 -name clk [get_ports clk]
