`timescale 1ns / 1ps
// =====================================================================
// FILE: tb_cpu_extra.v
// EXTRA CPU-LEVEL TEST (does not replace tb_cpu.v). It covers cases that
// tb_cpu.v does not check, using the program prog_extra.mem:
//   0 LDI R1,15 | 1 LDI R2,1 | 2 ADD R1,R2 | 3 LDI R3,7 | 4 MOV R0,R3
//   5 STORE R3,5 | 6 LOAD R2,5 | 7 ADD R2,R2 | 8-14 NOP | 15 LDI R0,9
//   1. Carry/Zero at CPU level for 15 + 1 (overflow to 0000)
//   2. LDI and MOV must NOT change the flags
//   3. LOAD directly after STORE sees the stored value
//   4. an instruction right after LOAD can use the loaded register
//   5. the PC wraps from 15 to 0 and address 0 runs again
// =====================================================================
module tb_cpu_extra;
    reg clk = 0;
    reg rst = 1;
    integer errors = 0;
    integer checks = 0;

    always #5 clk = ~clk;

    wire [3:0]  pc_out, alu_out, wb_data_out;
    wire [11:0] instr_out;
    wire        zero_out, carry_out;

    cpu_top #(.PROGRAM_FILE("prog_extra.mem")) CPU (
        .clk(clk), .rst(rst),
        .pc_out(pc_out), .instr_out(instr_out), .alu_out(alu_out),
        .wb_data_out(wb_data_out), .zero_out(zero_out), .carry_out(carry_out)
    );

    // wait until the instruction at address 'addr' has finished in EX
    task finish;
        input [3:0] addr;
        begin
            @(negedge clk);
            while (!(CPU.ex_valid && CPU.ex_pc == addr))
                @(negedge clk);
            @(posedge clk);
            #1;
        end
    endtask

    task check;
        input [8*44:1] name;
        input [3:0]    actual;
        input [3:0]    expected;
        begin
            checks = checks + 1;
            if (actual === expected)
                $display("PASS  %0s = %b", name, actual);
            else begin
                $display("FAIL  %0s = %b (expected %b)", name, actual, expected);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        rst = 1;
        @(posedge clk); @(posedge clk); #1;
        rst = 0;

        finish(2);
        check("ADD 15+1 -> R1 = 0000",              CPU.RF.r1, 4'b0000);
        check("ADD 15+1: Carry = 1",                {3'b000, carry_out}, 4'b0001);
        check("ADD 15+1: Zero = 1",                 {3'b000, zero_out},  4'b0001);

        finish(3);
        check("LDI R3,7 -> R3",                     CPU.RF.r3, 4'b0111);
        check("LDI keeps Zero (still 1)",           {3'b000, zero_out},  4'b0001);
        check("LDI keeps Carry (still 1)",          {3'b000, carry_out}, 4'b0001);

        finish(4);
        check("MOV R0,R3 -> R0",                    CPU.RF.r0, 4'b0111);
        check("MOV keeps Zero (still 1)",           {3'b000, zero_out},  4'b0001);
        check("MOV keeps Carry (still 1)",          {3'b000, carry_out}, 4'b0001);

        finish(5);
        check("STORE R3,5 -> data_memory[5]",       CPU.DMEM.mem[5], 4'b0111);

        finish(6);
        check("LOAD R2,5 right after STORE -> R2",  CPU.RF.r2, 4'b0111);

        finish(7);
        check("ADD R2,R2 uses R2 loaded just before", CPU.RF.r2, 4'b1110);
        check("ADD 7+7: Carry = 0",                 {3'b000, carry_out}, 4'b0000);
        check("ADD 7+7: Zero = 0",                  {3'b000, zero_out},  4'b0000);

        finish(15);
        check("LDI R0,9 at address 15 -> R0",       CPU.RF.r0, 4'b1001);
        finish(0);
        check("PC wrapped 15 -> 0: LDI R1,15 ran again", CPU.RF.r1, 4'b1111);

        $display("\n==================================================");
        if (errors == 0)
            $display("tb_cpu_extra PASSED: %0d of %0d checks OK", checks, checks);
        else
            $display("tb_cpu_extra FAILED: %0d of %0d checks failed", errors, checks);
        $display("==================================================\n");
        $finish;
    end
endmodule
